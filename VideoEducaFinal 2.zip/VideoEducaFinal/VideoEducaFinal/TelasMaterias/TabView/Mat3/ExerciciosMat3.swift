//
//  ExerciciosMat2.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct ExerciciosMat3: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ExerciciosMat3()
}
