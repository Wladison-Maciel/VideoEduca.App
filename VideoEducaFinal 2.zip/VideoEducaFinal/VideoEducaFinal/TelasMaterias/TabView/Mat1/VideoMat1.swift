
import Foundation
import SwiftUI
import WebKit

//Variaveis Logaritmos
struct Video: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}
//Variaveis Conjuntos
struct VideoC: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct VideoPA: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct VideoMat1: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    
    @State private var showRelatedVideos = false
    @State private var showRelatedVideosC = false
    @State private var showRelatedVideosPA = false
    @State private var selectedVideo: Video?
    @State private var selectedVideoC: VideoC?
    @State private var selectedVideoPA: VideoPA?
    
    
    //    Lista sobre Conjuntos
    let relatedVideos: [Video] = [
        Video(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        Video(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
    ]
//    Lista sobre Conjuntos
    let videosConjuntos: [VideoC] = [
        
        VideoC(title: "União e Intersecção", videoID: "c5a99sX-Sq8"),
        VideoC(title: "Propriedades dos Logaritmos", videoID: "GgqIUBwyQm4?si"),
    
    ]
    
    let videosPA: [VideoPA] = [
        
        VideoPA(title: "Progressão Geometrica", videoID: "c5a99sX-Sq8"),
    
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 85) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Matemática I")
                        .font(.system(size: 43, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -30)
                        
                }
            //                    Código sobre Logaritmos
            ScrollView {
                VStack {
                    Text("Logaritmos:")
                        .padding()
                        .font(.system(size: 28, weight: .semibold))
                        .offset(x: -115, y: 18)
                        .foregroundColor(.black)
                    
                    YTView(videoID: "esdFuyG7zGs")
                        .cornerRadius(15)
                    
                    Button(action: {
                        showRelatedVideos.toggle()
                    }) {
                        Text("Mostrar mais vídeos sobre Logaritmos")
                            .padding()
                            .foregroundColor(.black)
                            .font(.system(size: 20, weight: .semibold))
                    }
                    if showRelatedVideos {
                        Divider()
                        ForEach(relatedVideos) { video in
                            HStack {
                                Image(systemName: "play.fill")
                                    .foregroundColor(.red)
                                    .font(.system(size: 25))
                                
                                Button(action: {
                                    selectedVideo = video
                                }) {
                                    Text(video.title)
                                        .foregroundColor(.black)
                                        .padding()
                                }
                            }
                        }
                    }
                    Divider()
                    
                    //                    Código sobre Conjuntos
                    VStack{
                        Text("Conjuntos:")
                            .padding()
                            .font(.system(size: 28, weight: .semibold))
                            .offset(x: -115, y: 18)
                            .foregroundColor(.black)
                        
                        YTView(videoID: "rDEJDS5zJ3U")
                            .cornerRadius(15)
                        
                        Button(action: {
                            showRelatedVideosC.toggle()
                        }) {
                            Text("Mostrar mais vídeos sobre Conjuntos")
                                .padding()
                                .foregroundColor(.black)
                                .font(.system(size: 20, weight: .semibold))
                        }
                        if showRelatedVideosC {
                            Divider()
                            ForEach(videosConjuntos) { videoC in
                                HStack {
                                    Image(systemName: "play.fill")
                                        .foregroundColor(.red)
                                        .font(.system(size: 25))
                                    
                                    Button(action: {
                                        selectedVideoC = videoC
                                    }) {
                                        Text(videoC.title)
                                            .foregroundColor(.black)
                                            .padding()
                                    }
                                }
                            }
                        }
                        
                        Divider()
                        
                        VStack{
                            Text("Progressão Aritmética:")
                                .padding()
                                .font(.system(size: 28, weight: .semibold))
                                .offset(x: -42, y: 18)
                                .foregroundColor(.black)
                            
                            YTView(videoID: "waIXJzREyw8?si")
                                .cornerRadius(15)
                            
                            Button(action: {
                                showRelatedVideosPA.toggle()
                            }) {
                                Text("Mostrar mais vídeos sobre PA e PG")
                                    .padding()
                                    .foregroundColor(.black)
                                    .font(.system(size: 20, weight: .semibold))
                            }
                            if showRelatedVideosPA {
                                Divider()
                                ForEach(videosPA) { videoPA in
                                    HStack {
                                        Image(systemName: "play.fill")
                                            .foregroundColor(.red)
                                            .font(.system(size: 25))
                                        
                                        Button(action: {
                                            selectedVideoPA = videoPA
                                        }) {
                                            Text(videoPA.title)
                                                .foregroundColor(.black)
                                                .padding()
                                        }
                                    }
                                }
                            }
                            
    
                        }
                    }
                }
            }
            
//            Sheet Logaritmos
            
            .sheet(item: $selectedVideo) { video in
                YTView(videoID: video.videoID)
                    .navigationBarTitle(video.title, displayMode: .inline)
//                Sheet Conjuntos
                    }
            .sheet(item: $selectedVideoC) { videoC in
                YTView(videoID: videoC.videoID)
                    .navigationBarTitle(videoC.title, displayMode: .inline)
            }
            .sheet(item: $selectedVideoPA) { videoPA in
                YTView(videoID: videoPA.videoID)
                    .navigationBarTitle(videoPA.title, displayMode: .inline)
            }
        }
        
        .background(Color.white)
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonVideoMat1(presentationMode: presentationMode))
    }
}

func backButtonVideoMat1(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
            }
        }) {
            Image(systemName: "arrow.left")
                .foregroundColor(.white)
                .foregroundColor(.white)
                .frame(width: 64, height: 64)
                .offset(x: -10,y: -20)
        }
    }

#Preview {
    VideoMat1()
}
