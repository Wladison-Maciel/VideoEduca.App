//
//  ExerciciosMat1.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.

//

import SwiftUI

struct ExerciciosMat1: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        Text("Exercicios de matemática I aqui")
        
        
        
        
    }
}
func backButton5(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                            presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
                        }
        }) {
            Image(systemName: "arrow.left")
            .foregroundColor(.blue) // Cor do botão personalizado
            .frame(width: 64, height: 64) // Define o tamanho do botão
            .padding(.horizontal, 10) // Adiciona um padding ao redor do ícone
        }
    }

#Preview {
    ExerciciosMat1()
}
