//
//  ExerciciosMat2.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct ExerciciosMat2: View {
    var body: some View {
        Text("Exercicios de matemática I aqui")
    }
}

#Preview {
    ExerciciosMat2()
}
