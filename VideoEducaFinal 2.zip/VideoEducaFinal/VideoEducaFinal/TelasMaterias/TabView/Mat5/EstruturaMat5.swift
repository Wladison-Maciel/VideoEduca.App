//
//  EstruturaMat5.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct EstruturaMat5: View {
    var body: some View {
        TabView{
            VideoMat5()
                .tabItem {
                    Image(systemName: "video")
                    Text("Vídeo-Aula")
                }
                .background(Color.white)
            ExerciciosMat5()
                .tabItem {
                    Image(systemName: "book.pages")
                    Text("Exercícios")
                }
                .background(Color.white) // Fundo branco para a ScrollView
                        .ignoresSafeArea(.container, edges: .bottom)
        }
    }
}

#Preview {
    EstruturaMat5()
}
