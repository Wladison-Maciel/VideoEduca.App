//
//  ExerciciosMat5.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct ExerciciosMat5: View {
    var body: some View {
        Text("Mais exercícios em breve")
    }
}

#Preview {
    ExerciciosMat5()
}
