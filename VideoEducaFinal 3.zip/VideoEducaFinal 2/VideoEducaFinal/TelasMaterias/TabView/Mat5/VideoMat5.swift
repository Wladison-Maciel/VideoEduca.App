//
//  VideoMat5.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct VideoMat5: View {
    var body: some View {
        Text("Mais vídeos em breve")
    }
}

#Preview {
    VideoMat5()
}
