//
//  ExerciciosMat1.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.

//

import SwiftUI

struct ExerciciosMat2: View {
    
    @State private var SiteSenoCostg = "https://www.ime.unicamp.br/~valle/PastCourses/lista1.pdf"
    @State private var VideoSenoCosTg = "https://youtu.be/D-E_A04ReTE?si=FobLk7Wmg7smp3Ux"
    
    @State private var SiteNcMatriz = "https://docs.ufpr.br/~jomarc/exerciciosmatrizes2010.pdf"
    @State private var VideoNcMatriz = "https://youtu.be/7p6xzthF414?si=NN-2mIeB84m9m1Of"
    
    @State private var SiteMatrizInv = "https://ganuff.weebly.com/uploads/1/9/2/5/19255685/matrizes-determinantes-sistemas-lineares-e-inversa.pdf"
    @State private var VideoMatrizInv = "https://youtu.be/F10TdwBH8qc?si=N1ZBti3iBj8gKlgQ"
    
    @State private var SiteTeoPlace = "https://d3uyk7qgi7fgpo.cloudfront.net/lms/modules/materials/VOD-Teorema%20de%20Laplace-2019-de210f9f7f6e19c82b14f3686228b60c.pdf"
    @State private var VideoTeoPlace = "https://youtu.be/BGPLhQaZw64?si=9C4Tg69dls2GPLCS"
    
    var body: some View {
        VStack(spacing: 0) {
            
            
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Exercícios")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                }
            
            NavigationView {
                ZStack {
                    
                    // Conjuntos
                    
                    Text("Seno, Cosseno e Tangente")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -280)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteSenoCostg) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        if let url = URL(string: VideoSenoCosTg) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -211)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -210)
                   
                    // Logaritmo
                    
                    Text("Logaritmos")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -120)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteNcMatriz) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -40)
                    
                    Button(action: {
                        if let url = URL(string: VideoNcMatriz) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -40)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -40)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -40)
                    
                    // Progressao PA e PG
                    
                    Text("Teorema de Laplace")
                        .font(.system(size: 30))
                        .offset(x: 0,y: 50)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteMatrizInv) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 140)
                    
                    Button(action: {
                        if let url = URL(string: VideoMatrizInv) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 140)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 140)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 140)
                    
                    // Progressao PG
                    
                    Button(action: {
                        if let url = URL(string: SiteTeoPlace) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 230)
                    
                    Button(action: {
                        if let url = URL(string: VideoTeoPlace) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 230)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 230)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 230)
                }
                .background(Color.white) // Fundo branco para a NavigationView
                .ignoresSafeArea(.container, edges: .bottom)
                
                
            }
        }
    }
}
#Preview {
    ExerciciosMat2()
}
