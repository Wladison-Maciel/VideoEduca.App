//
//  VideoMat2.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.


// AINDA NAO FOI COLOCADO OS LINKS
//AJEITAR BOTAO DE VOLTAR

import Foundation
import SwiftUI
import WebKit

//Variaveis Logaritmos
struct VideoTr: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}
//Variaveis Conjuntos
struct VideoMat: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct VideoEquaL: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct VideoMat2: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    
    @State private var showRelatedVideosTr = false
    @State private var showRelatedVideosMat = false
    @State private var showRelatedVideosEquaL = false
    @State private var selectedVideosTr: VideoTr?
    @State private var selectedVideosMat: VideoMat?
    @State private var selectedVideosEqual: VideoEquaL?
    
    
    //    Lista sobre Conjuntos
    let VideosTrig: [VideoTr] = [
        VideoTr(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        VideoTr(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
    ]
//    Lista sobre Conjuntos
    let videosMat: [VideoMat] = [
        
        VideoMat(title: "Introdução", videoID: "c5a99sX-Sq8"),
        VideoMat(title: "Propriedades dos Logaritmos", videoID: "GgqIUBwyQm4?si"),
        
    
    ]
    
    let videosEquaL: [VideoEquaL] = [
        
        VideoEquaL(title: "Progressão Geometrica", videoID: "c5a99sX-Sq8"),
    
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 85) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Matemática II")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                        
                }
            //                    Código sobre Logaritmos
            ScrollView {
                VStack {
                    Text("Trigonometria:")
                        .padding()
                        .font(.system(size: 28, weight: .semibold))
                        .offset(x: -100, y: 18)
                        .foregroundColor(.black)
                    
                    YTView(videoID: "esdFuyG7zGs")
                        .cornerRadius(15)
                    
                    Button(action: {
                        showRelatedVideosTr.toggle()
                    }) {
                        Text("Mostrar mais vídeos sobre Trigonometria")
                            .padding()
                            .foregroundColor(.black)
                            .font(.system(size: 20, weight: .semibold))
                    }
                    if showRelatedVideosTr {
                        Divider()
                        ForEach(VideosTrig) { videoTr in
                            HStack {
                                Image(systemName: "play.fill")
                                    .foregroundColor(.red)
                                    .font(.system(size: 25))
                                
                                Button(action: {
                                    selectedVideosTr = videoTr
                                }) {
                                    Text(videoTr.title)
                                        .foregroundColor(.black)
                                        .padding()
                                }
                            }
                        }
                    }
                    Divider()
                    
                    //                    Código sobre Conjuntos
                    VStack{
                        Text("Matrizes:")
                            .padding()
                            .font(.system(size: 28, weight: .semibold))
                            .offset(x: -130, y: 18)
                            .foregroundColor(.black)
                        
                        YTView(videoID: "rDEJDS5zJ3U")
                            .cornerRadius(15)
                        
                        Button(action: {
                            showRelatedVideosMat.toggle()
                        }) {
                            Text("Mostrar mais vídeos sobre Matrizes")
                                .padding()
                                .foregroundColor(.black)
                                .font(.system(size: 20, weight: .semibold))
                        }
                        if showRelatedVideosMat {
                            Divider()
                            ForEach(videosMat) { videoMat in
                                HStack {
                                    Image(systemName: "play.fill")
                                        .foregroundColor(.red)
                                        .font(.system(size: 25))
                                    
                                    Button(action: {
                                        selectedVideosMat = videoMat
                                    }) {
                                        Text(videoMat.title)
                                            .foregroundColor(.black)
                                            .padding()
                                    }
                                }
                            }
                        }
                        
                        Divider()
                        
                        VStack{
                            Text("Equações Lineares:")
                                .padding()
                                .font(.system(size: 28, weight: .semibold))
                                .offset(x: -60, y: 18)
                                .foregroundColor(.black)
                            
                            YTView(videoID: "waIXJzREyw8?si")
                                .cornerRadius(15)
                            
                            Button(action: {
                                showRelatedVideosEquaL.toggle()
                            }) {
                                Text("Mostrar mais vídeos sobre Equações Lineares")
                                    .padding()
                                    .foregroundColor(.black)
                                    .font(.system(size: 20, weight: .semibold))
                            }
                            if showRelatedVideosEquaL {
                                Divider()
                                ForEach(videosEquaL) { videoEquaL in
                                    HStack {
                                        Image(systemName: "play.fill")
                                            .foregroundColor(.red)
                                            .font(.system(size: 25))
                                        
                                        Button(action: {
                                            selectedVideosEqual = videoEquaL
                                        }) {
                                            Text(videoEquaL.title)
                                                .foregroundColor(.black)
                                                .padding()
                                        }
                                    }
                                }
                            }
                            
    
                        }
                    }
                }
            }
            
//            Sheet Logaritmos
            
            .sheet(item: $selectedVideosTr) { videoTr in
                YTView(videoID: videoTr.videoID)
                    .navigationBarTitle(videoTr.title, displayMode: .inline)
//                Sheet Conjuntos
                    }
            .sheet(item: $selectedVideosMat) { VideoMat in
                YTView(videoID: VideoMat.videoID)
                    .navigationBarTitle(VideoMat.title, displayMode: .inline)
            }
            .sheet(item: $selectedVideosEqual) { VideoEquaL in
                YTView(videoID: VideoEquaL.videoID)
                    .navigationBarTitle(VideoEquaL.title, displayMode: .inline)
            }
        }
        
        .background(Color.white)
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonVideoMat1(presentationMode: presentationMode))
    }
}

func backButtonVideoMat2(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
            }
        }) {
            Image(systemName: "arrow.left")
                .foregroundColor(.white)
                .foregroundColor(.white)
                .frame(width: 64, height: 64)
                .offset(x: -10,y: -20)
        }
    }

#Preview {
    VideoMat2()
}
