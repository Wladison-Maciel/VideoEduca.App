//
//  VideoMat4.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct VideoMat4: View {
    var body: some View {
        Text("Mais vídeos em breve")
    }
}

#Preview {
    VideoMat4()
}
