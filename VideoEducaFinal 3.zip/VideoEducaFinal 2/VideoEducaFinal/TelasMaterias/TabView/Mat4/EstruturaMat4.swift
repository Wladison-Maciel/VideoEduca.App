//
//  EstruturaMat4.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct EstruturaMat4: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        TabView{
            VideoMat4()
                .tabItem {
                    Image(systemName: "video")
                    Text("Vídeo-Aula")
                }
                .background(Color.white)
            ExerciciosMat4()
                .tabItem {
                    Image(systemName: "book.pages")
                    Text("Exercícios")
                }
                .background(Color.white) // Fundo branco para a ScrollView
                        .ignoresSafeArea(.container, edges: .bottom)
        }
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonEstruMat4(presentationMode: presentationMode))
    }
}

func backButtonEstruMat4(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                            presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
                        }
        }) {
            Image(systemName: "arrow.left")
            .foregroundColor(.blue) // Cor do botão personalizado
            .frame(width: 64, height: 64) // Define o tamanho do botão
            .padding(.horizontal, -15) // Adiciona um padding ao redor do ícone
        }
    }

#Preview {
    EstruturaMat4()
}
