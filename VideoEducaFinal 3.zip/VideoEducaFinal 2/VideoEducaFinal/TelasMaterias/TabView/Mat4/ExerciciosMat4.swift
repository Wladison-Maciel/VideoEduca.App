//
//  ExerciciosMat4.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import SwiftUI

struct ExerciciosMat4: View {
    var body: some View {
        Text("Mais exercícios em breve")
    }
}

#Preview {
    ExerciciosMat4()
}
