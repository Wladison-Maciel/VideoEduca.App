//
//  ExerciciosMat1.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.

//

import SwiftUI

struct ExerciciosMat3: View {
    
    @State private var SitePRP = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-ponto-reta-plano-espaco.htm"
    @State private var VideoPRP = "https://youtu.be/Xe3ijQG5mtQ?si=6Eq5KiwzMjiZFHgn"
    
    @State private var SitePrismas = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-prisma.htm"
    @State private var VideoPrismas = "https://youtu.be/QjW6pSH0jVc?si=_EdhQ9MvqsbLhWfS"
    
    @State private var SitePAV = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-volume-prisma.htm"
    @State private var VideoPAV = "https://youtu.be/_sKcgx590J4?si=WKEqElHmJq-I7f1u"
    
    @State private var SiteEsfera = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-esfera.htm"
    @State private var VideoEsfera = "https://youtu.be/4mEqtfBXrl8?si=KjFrEZN2ykz9A69w"
    
    var body: some View {
        VStack(spacing: 0) {
            
            
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Exercícios")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                }
            
            NavigationView {
                ZStack {
                    
                    // Conjuntos
                    
                    Text("Ponto, Reta e Plano")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -280)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SitePRP) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        if let url = URL(string: VideoPRP) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -211)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -210)
                   
                    // Logaritmo
                    
                    Text("Prisma")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -120)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SitePrismas) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -40)
                    
                    Button(action: {
                        if let url = URL(string: VideoPrismas) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -40)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -40)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -40)
                    
                    // Progressao PA e PG
                    
                    Text("Prismas, Área e Volume")
                        .font(.system(size: 30))
                        .offset(x: 0,y: 50)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SitePAV) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 140)
                    
                    Button(action: {
                        if let url = URL(string: VideoPAV) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 140)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 140)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 140)
                    
                    // Progressao PG
                    
                    Button(action: {
                        if let url = URL(string: SiteEsfera) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 230)
                    
                    Button(action: {
                        if let url = URL(string: VideoEsfera) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 230)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 230)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 230)
                }
                .background(Color.white)
                .ignoresSafeArea(.container, edges: .bottom)
                
                
            }
        }
    }
}
#Preview {
    ExerciciosMat3()
}
