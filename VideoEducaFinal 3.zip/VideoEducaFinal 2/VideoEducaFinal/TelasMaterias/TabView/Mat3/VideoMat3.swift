//
//  VideoMat3.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

import Foundation
import SwiftUI
import WebKit

//Variaveis Logaritmos
struct VideoGeoEspacial: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct VideoMat3: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    
    @State private var showRelatedVideosGeoEspacial = false
    @State private var selectedVideosGeoEspacial: VideoGeoEspacial?
    
    
    
    //    Lista sobre Conjuntos
    let VideosGeo: [VideoGeoEspacial] = [
        VideoGeoEspacial(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        VideoGeoEspacial(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
        ]
    
    var body: some View {
        VStack(spacing: 0) {
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 85) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Matemática III")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                        
                }
            //                    Código sobre Logaritmos
            ScrollView {
                VStack {
                    Text("Geometria Espacial:")
                        .padding()
                        .font(.system(size: 28, weight: .semibold))
                        .offset(x: -65, y: 18)
                        .foregroundColor(.black)
                    
                    YTView(videoID: "esdFuyG7zGs")
                        .cornerRadius(15)
                    
                    Button(action: {
                        showRelatedVideosGeoEspacial.toggle()
                    }) {
                        Text("Mostrar mais vídeos sobre Geometria Espacial")
                            .padding()
                            .foregroundColor(.black)
                            .font(.system(size: 20, weight: .semibold))
                    }
                    if showRelatedVideosGeoEspacial{
                        Divider()
                        ForEach(VideosGeo) { videoGeo in
                            HStack {
                                Image(systemName: "play.fill")
                                    .foregroundColor(.red)
                                    .font(.system(size: 25))
                                
                                Button(action: {
                                    selectedVideosGeoEspacial = videoGeo
                                }) {
                                    Text(videoGeo.title)
                                        .foregroundColor(.black)
                                        .padding()
                                }
                            }
                        }
                    }
                    }
                }
            }
            
//            Sheet Logaritmos
            
            .sheet(item: $selectedVideosGeoEspacial) { videoGeoEspacial in
                YTView(videoID: videoGeoEspacial.videoID)
                    .navigationBarTitle(videoGeoEspacial.title, displayMode: .inline)

                    }
            .background(Color.white)
            .navigationBarBackButtonHidden(true)            .navigationBarItems(leading: backButtonVideoMat1(presentationMode: presentationMode))
        }
        
    }

func backButtonVideoMat3(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                presentationMode.wrappedValue.dismiss()
            }
        }) {
            Image(systemName: "arrow.left")
                .foregroundColor(.white)
                .foregroundColor(.white)
                .frame(width: 64, height: 64)
                .offset(x: -10,y: -20)
        }
    }

#Preview {
    VideoMat3()
}
