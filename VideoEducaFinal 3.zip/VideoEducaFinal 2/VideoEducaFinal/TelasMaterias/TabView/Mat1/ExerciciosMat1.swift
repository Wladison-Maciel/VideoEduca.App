//
//  ExerciciosMat1.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.

//

import SwiftUI

struct ExerciciosMat1: View {
    
    @State private var SiteLog = "https://matematicabasica.net/exercicios-sobre-logaritmo/"
    @State private var VideoLog = "https://youtu.be/sMUU3vJXBXA?si=nugTpReVKG6_fpI9"
    @State private var SiteConju = "https://www.todamateria.com.br/exercicios-sobre-conjuntos/"
    @State private var VideoConju = "https://youtu.be/gnZdzGqF9P8?si=xQ_gqyAnaeaSkbvz"
    @State private var SitePA = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-progressoes-aritmeticas.htm"
    @State private var VideoPA = "https://youtu.be/X6fTY7n-bZw?si=SIeIcdPDOQlK3Ih7"
    @State private var SitePG = "https://exercicios.mundoeducacao.uol.com.br/exercicios-matematica/exercicios-sobre-progressao-geometrica.htm"
    @State private var VideoPG = "https://youtu.be/g-lLVT68KOM?si=uqi6LC0lA2tVlMmz"
    
    var body: some View {
        VStack(spacing: 0) {
            
            
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75)
                .ignoresSafeArea()
                .overlay{
                    Text("Exercícios")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                }
            
            NavigationView {
                ZStack {
                    
                    // Conjuntos
                    
                    Text("Conjuntos")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -280)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteLog) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        if let url = URL(string: VideoLog) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -211)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -210)
                    ///---------------------//
                    ///
                    /// Logaritmo
                    ///
                    ///
                    Text("Logaritmos")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -120)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteConju) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -40)
                    
                    Button(action: {
                        if let url = URL(string: VideoConju) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -40)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -40)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -40)
                    
                    // Progressao PA e PG
                    
                    Text("Progressão PA/PG")
                        .font(.system(size: 30))
                        .offset(x: 0,y: 50)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SitePA) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 140)
                    
                    Button(action: {
                        if let url = URL(string: VideoPG) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 140)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 140)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 140)
                    
                    // Progressao PG
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SitePG) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 230)
                    
                    Button(action: {
                        if let url = URL(string: VideoPG) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 230)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 230)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 230)
                    
                    
                    
                }
                .background(Color.white)
                .ignoresSafeArea(.container, edges: .bottom)
                
                
            }
        }
    }
}

#Preview {
    ExerciciosMat1()
}
