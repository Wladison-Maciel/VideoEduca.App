import SwiftUI

struct Fisica: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        
        NavigationView {
            ZStack {
                Image("TelaFísica")
                    .edgesIgnoringSafeArea(.all)
                Image("IconFisica")
                    .resizable()
                    .frame(width: 70, height: 70)
                    .offset(x: -105, y: -335)
                    .foregroundColor(.white)
                
                Text("     FÍSICA")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
                    .padding(.top, -358)
                    .multilineTextAlignment(.trailing)
                    .bold()
                VStack(spacing: -66) {
                    VStack {
                        Spacer()
                        NavigationLink(destination: EstruturaMat1()) {
                            Text("Física I")
                                .font(.system(size: 30, weight: .bold))
                                .foregroundColor(.black)
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 30)
                        
                        NavigationLink(destination: EstruturaMat2()) {
                            Text("Física II")
                                .foregroundColor(.black)
                                .font(.system(size: 30, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)

                        Spacer().frame(height: 30)
                        
                        NavigationLink(destination: EstruturaMat3()) {
                            Text("Física III")
                                .foregroundColor(.black)
                                .font(.system(size: 30, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 30)
                        Spacer()
                    }
                    Spacer()
                    Spacer()

                }
                Image("IconFisI")
                    .resizable()
                    .frame(width: 65,height:65)
                    .offset(x: -107, y: -68)
                    .allowsHitTesting(false)
                Image("IconFisII")
                    .resizable()
                    .frame(width: 65,height: 65)
                    .offset(x: -107, y: 44)
                    .allowsHitTesting(false)
                Image("IconFisIII")
                    .resizable()
                    .frame(width: 65,height: 65)
                    .offset(x: -107, y: 150)
                    .allowsHitTesting(false)
                

            }
        }
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonFisica(presentationMode: presentationMode))
        
    }
}
func backButtonFisica(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                            presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
                        }
        }) {
            Image(systemName: "arrow.left")
            .foregroundColor(.white)
            .frame(width: 64, height: 64)
            .padding(.horizontal, -15)
        }
    }
#Preview {
    Fisica()
}


