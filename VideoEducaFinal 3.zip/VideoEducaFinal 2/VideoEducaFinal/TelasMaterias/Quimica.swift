//
//  Quimica.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.
//

//
//  testeMatematica.swift
//  VideoEducaFinal
//
//  Created by User on 17/11/23.
//

import SwiftUI

struct Quimica: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        
        NavigationView {
            ZStack {
                Image("TelaQuimica")
                    .edgesIgnoringSafeArea(.all)
                Image("IconQuimica")
                    .resizable()
                    .frame(width: 90, height: 90)
                    .offset(x: -105, y: -335)
                    .foregroundColor(.white)
                
                Text("     QUÍMICA")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
                    .padding(.top, -355)
                    .multilineTextAlignment(.trailing)
                    .bold()
                VStack(spacing: -66 ) {
                    VStack {
                        Spacer()
                        NavigationLink(destination: EstruturaQui1()) {
                            Text("Química I")
                                .font(.system(size: 30, weight: .bold))
                                .foregroundColor(.black)
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 30)
                        
                        NavigationLink(destination: EstruturaQui2()) {
                            Text("Química II")
                                .foregroundColor(.black)
                                .font(.system(size: 30, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)

                        Spacer().frame(height: 30)
                        
                        NavigationLink(destination: EstruturaQui3()) {
                            Text("Química III")
                                .foregroundColor(.black)
                                .font(.system(size: 30, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 30)
                        Spacer()
                    }
                    Spacer()
                    Spacer()

                }
                Image("IconQuiI")
                    .resizable()
                    .frame(width: 58,height: 58)
                    .offset(x: -107, y: -68)
                    .allowsHitTesting(false)
                Image("IconQuiII")
                    .resizable()
                    .frame(width: 55,height: 55)
                    .offset(x: -107, y: 43)
                    .allowsHitTesting(false)
                Image("IconQuiIII")
                    .resizable()
                    .frame(width: 60,height: 60)
                    .offset(x: -107, y: 153)
                    .allowsHitTesting(false)
                

            }
        }
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonQuimica(presentationMode: presentationMode))
        
    }
}
func backButtonQuimica(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                            presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
                        }
        }) {
            Image(systemName: "arrow.left")
            .foregroundColor(.white)
            .frame(width: 64, height: 64)
            .padding(.horizontal, -15)
        }
    }
#Preview {
    Quimica()
}

