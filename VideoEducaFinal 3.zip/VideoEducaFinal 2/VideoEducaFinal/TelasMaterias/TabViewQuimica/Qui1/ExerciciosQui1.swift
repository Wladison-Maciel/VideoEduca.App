//
//  ExerciciosQui1.swift
//  VideoEducaFinal
//
//  Created by User on 13/12/23.
//

import SwiftUI

import SwiftUI

struct ExerciciosQui1: View {
    
    @State private var SiteMatClass = "https://www.profpc.com.br/Exerc%C3%ADcios%20de%20Qu%C3%ADmica/Setor%20Omega/%C3%94mega%20-%20M%C3%B3dulo%201.pdf"
    @State private var VideoMatClass = ""
    
    @State private var SiteMisturas = "https://www.profpc.com.br/Exerc%C3%ADcios%20de%20Qu%C3%ADmica/Setor%20Omega/%C3%94mega%20-%20M%C3%B3dulo%202.pdf"
    @State private var VideoMisturas = "https://youtu.be/hbwKwNhIFM4?si=eCSFYF7L8wrCvkcp"
    
    @State private var SiteLigQui = "https://www.todamateria.com.br/exercicios-de-ligacoes-quimicas/"
    @State private var VideoLigQUi = "https://youtu.be/UjXlHX3EEi0?si=yw8SI9pj4g5RjCtB"
    
    var body: some View {
        VStack(spacing: 0) {
            
            
            Image("RectangleQui")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Exercícios")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                }
            
            NavigationView {
                ZStack {
                    
                    // Estudo da matéria e suas classificacoes
                    
                    Text("Estudo da máteria")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -310)
                        .bold()
                    Text("e suas classificações")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -275)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteMatClass) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoesQui"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        if let url = URL(string: VideoMatClass) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoesQui"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -211)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -210)
                    
                    // Logaritmo
                    
                    Text("Misturas")
                        .font(.system(size: 30))
                        .offset(x: 0,y: -120)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteMisturas) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoesQui"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: -40)
                    
                    Button(action: {
                        if let url = URL(string: VideoMisturas) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 30)
                            .padding()
                            .background(Color("CorBotoesQui"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: -40)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: -40)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: -40)
                    
                    // Progressao PA e PG
                    
                    Text("Ligações Química")
                        .font(.system(size: 30))
                        .offset(x: 0,y: 50)
                        .bold()
                    
                    Button(action: {
                        if let url = URL(string: SiteLigQui) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoesQui"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                    }
                    .offset(x: -100,y: 140)
                    
                    Button(action: {
                        if let url = URL(string: VideoLigQUi) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 24, weight: .semibold))
                            .frame(width: 120, height: 25)
                            .padding()
                            .background(Color("CorBotoesQui"))
                            .foregroundColor(.white)
                            .cornerRadius(15)
                        
                    }
                    
                    .offset(x: 100,y: 140)
                    
                    Image("IconSite")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: -135, y: 140)
                    
                    Image("IconVideos")
                        .resizable()
                        .frame(width: 35, height: 35)
                        .offset(x: 55, y: 140)
                    
                }
                .background(Color.white) // Fundo branco para a NavigationView
                .ignoresSafeArea(.container, edges: .bottom)
                
                
            }
        }
    }
}
#Preview {
    ExerciciosQui1()
}
