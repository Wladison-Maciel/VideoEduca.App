//
//  VideoQui1.swift
//  VideoEducaFinal
//
//  Created by User on 11/12/23.
//
import Foundation
import SwiftUI
import WebKit

//Variaveis Logaritmos
struct EstudoDaMateria: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct SubsPuraMistura: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct Misturas: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}

struct EstruturaDaMateria: Identifiable {
    let id = UUID()
    let title: String
    let videoID: String
}


struct VideoQui1: View {
    
    
    @State private var showRelatedVideosEstudoDaMateria = false
    @State private var selectedVideosEstudoDaMateria: EstudoDaMateria?
    @State private var showRelatedVideosSubsParaMistura = false
    @State private var selectedVideosSubsPuraMistura: SubsPuraMistura?
    @State private var showRelatedVideosMisturas = false
    @State private var selectedVideosMisturas: Misturas?
    @State private var showRelatedVideosEstruturaDaMateria = false
    @State private var selectedVideosEstruturaDaMateria: EstruturaDaMateria?
    
    
    
    //    Lista sobre Conjuntos
    let EstudoDaMaterias: [EstudoDaMateria] = [
        EstudoDaMateria(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        EstudoDaMateria(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
        
    ]
    
    let SubsPuraMisturas: [SubsPuraMistura] = [
        SubsPuraMistura(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        SubsPuraMistura(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
        
    ]
    
    let Mistura: [Misturas] = [
        Misturas(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        Misturas(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
        
    ]
    
    let EstruturaDaMaterias: [EstruturaDaMateria] = [
        EstruturaDaMateria(title: "Introdução Parte 2", videoID: "BzbzlRyaj2U"),
        EstruturaDaMateria(title: "Propriedades dos Logaritmos", videoID: "3ennIevODaA?si"),
        
    ]
    
    
    var body: some View {
        VStack(spacing: 0) {
            Image("RectangleQui")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 85) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Química I")
                        .font(.system(size: 43, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -40)
                    
                }
            //                    Código sobre Logaritmos
            ScrollView {
                VStack {
                    Text("Estudo da Materia:")
                        .padding()
                        .font(.system(size: 28, weight: .semibold))
                        .offset(x: -65, y: 18)
                        .foregroundColor(.black)
                    
                    YTView(videoID: "ANnkstfG6nE?si")
                        .cornerRadius(15)
                    
                    Button(action: {
                        showRelatedVideosEstudoDaMateria.toggle()
                    }) {
                        Text("Mostrar mais vídeos sobre Materia")
                            .padding()
                            .foregroundColor(.black)
                            .font(.system(size: 20, weight: .semibold))
                    }
                    if showRelatedVideosEstudoDaMateria{
                        Divider()
                        ForEach(EstudoDaMaterias) { EstudoDaMaterias in
                            HStack {
                                Image(systemName: "play.fill")
                                    .foregroundColor(.red)
                                    .font(.system(size: 25))
                                
                                Button(action: {
                                    selectedVideosEstudoDaMateria = EstudoDaMaterias
                                }) {
                                    Text(EstudoDaMaterias.title)
                                        .foregroundColor(.black)
                                        .padding()
                                }
                            }
                        }
                    }
                    Divider()
                    VStack {
                        Text("Misturas:")
                            .padding()
                            .font(.system(size: 28, weight: .semibold))
                            .offset(x: -125, y: 18)
                            .foregroundColor(.black)
                        
                        YTView(videoID: "hbwKwNhIFM4?si")
                            .cornerRadius(15)
                        
                        Button(action: {
                            showRelatedVideosMisturas.toggle()
                        }) {
                            Text("Mostrar mais vídeos sobre Misturas")
                                .padding()
                                .foregroundColor(.black)
                                .font(.system(size: 20, weight: .semibold))
                        }
                        if showRelatedVideosMisturas{
                            Divider()
                            ForEach(Mistura) { Misturas in
                                HStack {
                                    Image(systemName: "play.fill")
                                        .foregroundColor(.red)
                                        .font(.system(size: 25))
                                    
                                    Button(action: {
                                        selectedVideosMisturas = Misturas
                                    }) {
                                        Text(Misturas.title)
                                            .foregroundColor(.black)
                                            .padding()
                                    }
                                }
                            }
                        }
                        Divider()
                        
                        
                    }
                }
            }
        }
        
        .sheet(item: $selectedVideosEstudoDaMateria) { EstudoDaMaterias in
            YTView(videoID: EstudoDaMaterias.videoID)
                .navigationBarTitle(EstudoDaMaterias.title, displayMode: .inline)
            //                Sheet Conjuntos
        }
        .sheet(item: $selectedVideosMisturas) { Misturas in
            YTView(videoID: Misturas.videoID)
                .navigationBarTitle(Misturas.title, displayMode: .inline)
    }
            .background(Color.white)
        }
        
    }

#Preview {
    VideoQui1()
}
