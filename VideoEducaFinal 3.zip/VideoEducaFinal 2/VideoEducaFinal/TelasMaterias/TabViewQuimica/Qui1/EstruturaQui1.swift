//
//  EstruturaQui1.swift
//  VideoEducaFinal
//
//  Created by User on 24/11/23.
//

import SwiftUI

struct EstruturaQui1: View {
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        TabView{
            VideoQui1()
                .tabItem {
                    Image(systemName: "video")
                    Text("Vídeo-Aula")
                }
                .background(Color.white)
            ExerciciosQui1()
                .tabItem {
                    Image(systemName: "book.pages")
                    Text("Exercícios")
                }
                .background(Color.white) // Fundo branco para a ScrollView
                        .ignoresSafeArea(.container, edges: .bottom)
        }
        
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonVideoQui1(presentationMode: presentationMode))
    }
}

func backButtonVideoQui1(presentationMode: Binding<PresentationMode>) -> some View {
        Button(action: {
            withAnimation(.linear) {
                presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
            }
        }) {
            Image(systemName: "arrow.left")
                .foregroundColor(.white)
                .foregroundColor(.white)
                .frame(width: 64, height: 64)
                .offset(x: -10,y: 0)
        }
    }

#Preview {
    EstruturaQui1()
}
