//
//  VideoQui3.swift
//  VideoEducaFinal
//
//  Created by User on 13/12/23.
//

import SwiftUI

struct VideoQui3: View {
    var body: some View {
        Text("Mais vídeos em breve")
    }
}

#Preview {
    VideoQui3()
}
