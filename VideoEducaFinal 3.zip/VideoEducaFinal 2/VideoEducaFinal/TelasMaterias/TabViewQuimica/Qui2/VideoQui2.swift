//
//  VideoQui2.swift
//  VideoEducaFinal
//
//  Created by User on 13/12/23.
//

import SwiftUI

struct VideoQui2: View {
    var body: some View {
        Text("Mais videos em breve")
    }
}

#Preview {
    VideoQui2()
}
