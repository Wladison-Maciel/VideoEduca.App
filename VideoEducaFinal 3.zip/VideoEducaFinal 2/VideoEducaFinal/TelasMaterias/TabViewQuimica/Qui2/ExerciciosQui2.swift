//
//  ExerciciosQui2.swift
//  VideoEducaFinal
//
//  Created by User on 13/12/23.
//

import SwiftUI

struct ExerciciosQui2: View {
    var body: some View {
        Text("Mais exercícios em breve")
    }
}

#Preview {
    ExerciciosQui2()
}
