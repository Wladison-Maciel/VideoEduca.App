//
//  YTView.swift
//  teste3
//
//  Created by User on 08/12/23.
//

import SwiftUI
import WebKit

struct YTView: View {
    let videoID: String
    
    var body: some View {
        WebView(urlString: "https://www.youtube.com/embed/\(videoID)")
            .frame(width: 380, height: 250)
    }
}

#Preview {
    YTView(videoID: "")
}


struct WebView: UIViewRepresentable {
    let urlString: String
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        if let youtubeURL = URL(string: urlString) {
            let request = URLRequest(url: youtubeURL)
            uiView.load(request)
        }
    }
}
