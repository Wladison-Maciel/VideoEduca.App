//
//  ExerciciosMat1.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.

//

import SwiftUI

struct ExerciciosMat2: View {
    
    @State private var SiteSenoCostg = "https://www.ime.unicamp.br/~valle/PastCourses/lista1.pdf"
    @State private var VideoSenoCosTg = "https://youtu.be/D-E_A04ReTE?si=FobLk7Wmg7smp3Ux"
    
    @State private var SiteNcMatriz = "https://docs.ufpr.br/~jomarc/exerciciosmatrizes2010.pdf"
    @State private var VideoNcMatriz = "https://youtu.be/7p6xzthF414?si=NN-2mIeB84m9m1Of"
    
    @State private var SiteMatrizInv = "https://ganuff.weebly.com/uploads/1/9/2/5/19255685/matrizes-determinantes-sistemas-lineares-e-inversa.pdf"
    @State private var VideoMatrizInv = "https://youtu.be/F10TdwBH8qc?si=N1ZBti3iBj8gKlgQ"
    
    @State private var SiteTeoPlace = "https://d3uyk7qgi7fgpo.cloudfront.net/lms/modules/materials/VOD-Teorema%20de%20Laplace-2019-de210f9f7f6e19c82b14f3686228b60c.pdf"
    @State private var VideoTeoPlace = "https://youtu.be/BGPLhQaZw64?si=9C4Tg69dls2GPLCS"
    
    var body: some View {
        VStack(spacing: 0) {
            
            
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Exercícios")
                        .font(.system(size: 43, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                }
            
            NavigationView {
                ZStack {
                    
                    // Conjuntos
                    
                    Text("Seno, Cos, Tangente")
                        .font(.system(size: 40))
                        .offset(x: 0,y: -280)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SiteSenoCostg) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoSenoCosTg) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: -211)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: -210)
                    ///---------------------//
                    ///
                    /// Logaritmo
                    ///
                    ///
                    Text("Noção de Matrizes")
                        .font(.system(size: 40))
                        .offset(x: 0,y: -120)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SiteNcMatriz) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: -40)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoNcMatriz) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: -40)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: -40)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: -40)
                    
                    //-----------------------
                    
                    // Progressao PA e PG
                    
                    Text("Matriz Inversa")
                        .font(.system(size: 40))
                        .offset(x: 0,y: 50)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SiteMatrizInv) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: 140)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoMatrizInv) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: 140)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: 140)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: 140)
                    
                    // teorema de laplace
                    Text("Teorema de Laplace")
                        .font(.system(size: 40))
                        .offset(x: 0,y: 230)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SiteTeoPlace) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: 320)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoTeoPlace) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: 320)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: 320)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: 320)
                    
                    
                    
                }
                
                
            }
        }
    }
}
#Preview {
    ExerciciosMat2()
}
