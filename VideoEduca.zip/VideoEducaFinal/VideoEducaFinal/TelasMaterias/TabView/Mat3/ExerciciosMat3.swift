//
//  ExerciciosMat1.swift
//  VideoEducaFinal
//
//  Created by User on 14/11/23.

//

import SwiftUI

struct ExerciciosMat3: View {
    
    @State private var SitePRP = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-ponto-reta-plano-espaco.htm"
    @State private var VideoPRP = "https://youtu.be/Xe3ijQG5mtQ?si=6Eq5KiwzMjiZFHgn"
    
    @State private var SitePrismas = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-prisma.htm"
    @State private var VideoPrismas = "https://youtu.be/QjW6pSH0jVc?si=_EdhQ9MvqsbLhWfS"
    
    @State private var SitePAV = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-volume-prisma.htm"
    @State private var VideoPAV = "https://youtu.be/_sKcgx590J4?si=WKEqElHmJq-I7f1u"
    
    @State private var SiteEsfera = "https://exercicios.brasilescola.uol.com.br/exercicios-matematica/exercicios-sobre-esfera.htm"
    @State private var VideoEsfera = "https://youtu.be/4mEqtfBXrl8?si=KjFrEZN2ykz9A69w"
    
    var body: some View {
        VStack(spacing: 0) {
            
            
            Image("Rectangle")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 75) // Altura da imagem
                .ignoresSafeArea()
                .overlay{
                    Text("Exercícios")
                        .font(.system(size: 43, weight: .semibold))
                        .foregroundColor(.white)
                        .offset(y: -50)
                }
            
            NavigationView {
                ZStack {
                    
                    // Conjuntos
                    
                    Text("Ponto, reta e plano")
                        .font(.system(size: 40))
                        .offset(x: 0,y: -280)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SitePRP) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: -210)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoPRP) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: -210)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: -211)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: -210)
                    ///---------------------//
                    ///
                    /// Logaritmo
                    ///
                    ///
                    Text("Prismas")
                        .font(.system(size: 40))
                        .offset(x: 0,y: -120)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SitePrismas) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: -40)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoPrismas) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: -40)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: -40)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: -40)
                    
                    //-----------------------
                    
                    // Progressao PA e PG
                    
                    Text("Prismas, área/Volume")
                        .font(.system(size: 40))
                        .offset(x: 0,y: 50)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SitePAV) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: 140)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoPAV) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: 140)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: 140)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: 140)
                    
                    // teorema de laplace
                    Text("Esfera")
                        .font(.system(size: 40))
                        .offset(x: 0,y: 230)
                        .bold()
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: SiteEsfera) {
                            UIApplication.shared.open(url)
                        }
                    }) {
                        Text("       Site")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 140, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                    }
                    .offset(x: -100,y: 320)
                    
                    Button(action: {
                        // Abre o site quando o botão é pressionado
                        if let url = URL(string: VideoEsfera) {
                            UIApplication.shared.open(url)
                        }
                        
                    }) {
                        Text("       Video")
                            .font(.system(size: 27, weight: .semibold))
                            .frame(width: 135, height: 30)
                            .padding()
                            .background(Color("CorBotoes"))
                            .foregroundColor(.white)
                            .cornerRadius(20)
                        
                    }
                    
                    .offset(x: 100,y: 320)
                    
                    Image("IconSite") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: -135, y: 320)
                    
                    Image("IconVideos") // Imagem sobreposta (substitua com sua própria imagem)
                        .resizable()
                        .frame(width: 40, height: 40)
                        .offset(x: 55, y: 320)
                    
                    
                    
                }
                
                
            }
        }
    }
}
#Preview {
    ExerciciosMat3()
}
