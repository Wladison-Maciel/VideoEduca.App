//
//  testeMatematica.swift
//  VideoEducaFinal
//
//  Created by User on 17/11/23.
//

import SwiftUI

struct Matematica: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    
    var body: some View {
        
        NavigationView {
            ZStack {
                Image("TelaMatematica")
                    .edgesIgnoringSafeArea(.all)
                Image("IconeMat")
                    .offset(x: -127, y: -320)
                    .foregroundColor(.white)
                
                Text("          MATEMÁTICA")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
                    .padding(.top, -342)
                    .multilineTextAlignment(.trailing)
                    .bold()
                VStack(spacing: -66) {
                    VStack {
                        Spacer()
                        NavigationLink(destination: EstruturaMat1()) {
                            Text("Matemática I")
                                .font(.system(size: 25, weight: .bold))
                                .foregroundColor(.black)
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 15)
                        
                        NavigationLink(destination: EstruturaMat2()) {
                            Text("Matemática II")
                                .foregroundColor(.black)
                                .font(.system(size: 25, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)

                        Spacer().frame(height: 15)
                        
                        NavigationLink(destination: EstruturaMat3()) {
                            Text("Matemática III")
                                .foregroundColor(.black)
                                .font(.system(size: 25, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 15)
                        
                        NavigationLink(destination: EstruturaMat4()) {
                            Text("Matemática IV")
                                .foregroundColor(.black)
                                .font(.system(size: 25, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 15)
                        
                        NavigationLink(destination: EstruturaMat5()) {
                            Text("Matemática V")
                                .foregroundColor(.black)
                                .font(.system(size: 25, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 15)
                        
                        NavigationLink(destination: EstruturaMat6()) {
                            Text("Matemática VI")
                                .foregroundColor(.black)
                                .font(.system(size: 25, weight: .bold))
                                .padding(.vertical, 45)
                                .frame(width: 270, height: 50)
                                .padding()
                                .offset(x: 15, y: 0)
                        }
                        .background(Color.white)
                        .cornerRadius(10)
                        Spacer().frame(height: 15)
                        Spacer()
                    }
                    Spacer()
                    Spacer()

                }
                Image("IconMatI")
                    .resizable()
                    .frame(width: 50,height: 50)
                    .offset(x: -107, y: -190)
                    .allowsHitTesting(false)
                Image("IconMatII")
                    .resizable()
                    .frame(width: 64,height: 64)
                    .offset(x: -107, y: -96)
                    .allowsHitTesting(false)
                Image("IconMatIII")
                    .resizable()
                    .frame(width: 64,height: 64)
                    .offset(x: -112, y: 1)
                    .allowsHitTesting(false)
                Image("IconMatIV")
                    .resizable()
                    .frame(width: 55,height: 55)
                    .offset(x: -113, y:97)
                    .allowsHitTesting(false)
                Image("IconMatV")
                    .resizable()
                    .frame(width: 56,height: 56)
                    .offset(x: -109, y: 194)
                    .allowsHitTesting(false)
                Image("IconMatVI")
                    .resizable()
                    .frame(width: 64,height: 64)
                    .offset(x: -109, y: 291)
                    .allowsHitTesting(false)
                // Todos os icones utilizados nas telas

            }
        }
        .navigationBarBackButtonHidden(true) // Oculta o botão de volta padrão
        .navigationBarItems(leading: backButtonMatematica(presentationMode: presentationMode))
        
    }
}
func backButtonMatematica(presentationMode: Binding<PresentationMode>) -> some View {
    Button(action: {
        withAnimation(.linear) {
            presentationMode.wrappedValue.dismiss() // Isso volta para a tela anterior com animação
        }
    }) {
        Image(systemName: "arrow.left")
            .foregroundColor(.white) // Cor do botão personalizado
            .frame(width: 64, height: 64) // Define o tamanho do botão
            .padding(.horizontal, -15)
    }
}
#Preview {
    Matematica()
}

