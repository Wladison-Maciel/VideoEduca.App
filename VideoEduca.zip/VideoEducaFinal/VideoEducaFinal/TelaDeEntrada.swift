//
//  ContentView.swift
//  SwiftUIView
//
//  Created by User on 17/10/23.
//

import SwiftUI

struct TelaDeEntrada: View {
    
    @AppStorage("username") var username: String = ""
    
    var body: some View {
        NavigationStack {
            ZStack{
                
                Color.blue
                    .ignoresSafeArea(.all)
                Image("Frame")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 400, height: 100)
                    .offset(x: 0, y:150)
                
                VStack {
                    
                    
                    Image(systemName: "person.crop.circle")
                        .resizable()
                        .frame(width: 150, height: 150)
                        .padding()
                        .offset(x: 0, y: 105)
                        .foregroundColor(.white.opacity(0.9))
                    
                    TextField("Nome", text: $username)
                        .font(.system(size: 20))
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.black.opacity(0.1))) // Fundo arredondado
                        .multilineTextAlignment(.center) // Texto centralizado
                        .frame(width: 300, height: 50)
                        .offset(x: 0, y:400) // posiçao do campo de texto
                    Spacer()
                    Spacer()
                    NavigationLink(destination: HelloView()) {
                        Text("Entrar")
                            .font(.system(size: 23, weight: .bold))
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 150, height: 50)
                        
                    }
                    .background(Color.blue)
                    .cornerRadius(25)
                    .offset(x:0, y: 215)
                    
                    Spacer()
                    Spacer()
                }
            }
        }
    }
}
#Preview {
    TelaDeEntrada()
}
